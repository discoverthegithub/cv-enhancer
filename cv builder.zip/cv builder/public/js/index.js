// Form submission handler
document.getElementById('cvForm').addEventListener('submit', async function(e) {
  e.preventDefault();
  
  const fileInput = document.getElementById('resumeFile');
  const jobTitleInput = document.getElementById('jobTitle');
  const promptInput = document.getElementById('prompt');
  const status = document.getElementById('status');
  const downloadLink = document.getElementById('downloadLink');
  const pdfPreview = document.getElementById('pdfPreview');
  
  // Reset UI
  status.textContent = '';
  status.classList.remove('visible');
  downloadLink.classList.remove('show');
  
  // Hide PDF preview on new submission or error
  if (pdfPreview) {
    pdfPreview.style.display = 'none';
    pdfPreview.src = '';
  }

  // Validate file
  if (!fileInput.files.length) {
    status.textContent = 'Please select a file.';
    status.classList.add('visible');
    return;
  }
  
  const file = fileInput.files[0];
  const maxSize = 10 * 1024 * 1024; // 10MB
  
  if (file.size > maxSize) {
    status.textContent = 'File size too large. Please select a file smaller than 10MB.';
    status.classList.add('visible');
    return;
  }
  
  // Prepare form data
  const formData = new FormData();
  formData.append('file', file);
  
  if (jobTitleInput.value.trim()) {
    formData.append('jobTitle', jobTitleInput.value.trim());
  }
  
  if (promptInput.value.trim()) {
    formData.append('prompt', promptInput.value.trim());
  }
  
  // Show processing status
  status.textContent = 'Enhancing your CV... Please wait.';
  status.classList.add('visible');
  
  try {
    // Send to backend
    const response = await fetch('/webhook/resume-builder', {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.details || 'Failed to enhance CV');
    }
    
    // Get the enhanced CV as blob
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    
    // Update download link
    downloadLink.href = url;
    downloadLink.classList.add('show');
    
    // Show PDF preview
    if (pdfPreview) {
      pdfPreview.src = url;
      pdfPreview.style.display = 'block';
    }
    
    // Success message
    status.textContent = 'Your enhanced CV is ready!';
    status.classList.add('visible');
    
    // Optional: Auto-download after a short delay
    setTimeout(() => {
      downloadLink.click();
    }, 1000);
    
  } catch (error) {
    console.error('Error:', error);
    status.textContent = `Error: ${error.message}`;
    status.classList.add('visible');
  }
});

// File upload area drag and drop functionality
const dropArea = document.getElementById('dropArea');
const fileInput = document.getElementById('resumeFile');

if (dropArea && fileInput) {
  ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, preventDefaults, false);
  });

  function preventDefaults(e) {
    e.preventDefault();
    e.stopPropagation();
  }

  ['dragenter', 'dragover'].forEach(eventName => {
    dropArea.addEventListener(eventName, highlight, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropArea.addEventListener(eventName, unhighlight, false);
  });

  function highlight(e) {
    dropArea.classList.add('highlight');
  }

  function unhighlight(e) {
    dropArea.classList.remove('highlight');
  }

  dropArea.addEventListener('drop', handleDrop, false);

  function handleDrop(e) {
    const dt = e.dataTransfer;
    const files = dt.files;
    
    if (files.length > 0) {
      fileInput.files = files;
      // Trigger change event to update UI
      const event = new Event('change', { bubbles: true });
      fileInput.dispatchEvent(event);
    }
  }

  // File input change handler
  fileInput.addEventListener('change', function() {
    if (this.files.length > 0) {
      const file = this.files[0];
      const fileName = file.name;
      const fileSize = (file.size / 1024 / 1024).toFixed(2);
      
      // Update drop area to show selected file
      dropArea.innerHTML = `
        <i class="fas fa-file-alt"></i>
        <p><strong>${fileName}</strong></p>
        <p>Size: ${fileSize} MB</p>
        <p>Click to change file</p>
      `;
    }
  });
}

// Modal functionality (if you have modals)
const modals = document.querySelectorAll('.modal');
const closeButtons = document.querySelectorAll('.close-modal');

closeButtons.forEach(button => {
  button.addEventListener('click', function() {
    const modal = this.closest('.modal');
    modal.style.display = 'none';
  });
});

// Close modal when clicking outside
window.addEventListener('click', function(event) {
  modals.forEach(modal => {
    if (event.target === modal) {
      modal.style.display = 'none';
    }
  });
}); 