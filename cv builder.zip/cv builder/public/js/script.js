document.addEventListener('DOMContentLoaded', function() {
    const cvForm = document.getElementById('cvForm');
    const dropArea = document.getElementById('dropArea');
    const fileInput = document.getElementById('resumeFile');
    const statusModal = document.getElementById('statusModal');
    const resultModal = document.getElementById('resultModal');
    const closeModals = document.querySelectorAll('.close-modal');
    const downloadLink = document.getElementById('downloadLink');
    
    // Drag and drop functionality
    ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
      dropArea.addEventListener(eventName, preventDefaults, false);
    });
  
    function preventDefaults(e) {
      e.preventDefault();
      e.stopPropagation();
    }
  
    ['dragenter', 'dragover'].forEach(eventName => {
      dropArea.addEventListener(eventName, highlight, false);
    });
  
    ['dragleave', 'drop'].forEach(eventName => {
      dropArea.addEventListener(eventName, unhighlight, false);
    });
  
    function highlight() {
      dropArea.classList.add('highlight');
    }
  
    function unhighlight() {
      dropArea.classList.remove('highlight');
    }
  
    dropArea.addEventListener('drop', handleDrop, false);
  
    function handleDrop(e) {
      const dt = e.dataTransfer;
      const files = dt.files;
      fileInput.files = files;
      updateFileDisplay(files[0]);
    }
  
    fileInput.addEventListener('change', function() {
      if (this.files.length) {
        updateFileDisplay(this.files[0]);
      }
    });
  
    function updateFileDisplay(file) {
      const fileDisplay = document.createElement('div');
      fileDisplay.className = 'file-display';
      fileDisplay.innerHTML = `
        <i class="fas fa-file-alt"></i>
        <div class="file-info">
          <span class="file-name">${file.name}</span>
          <span class="file-size">${formatFileSize(file.size)}</span>
        </div>
        <button class="remove-file"><i class="fas fa-times"></i></button>
      `;
      
      // Remove any existing file display
      const existingDisplay = dropArea.querySelector('.file-display');
      if (existingDisplay) {
        existingDisplay.remove();
      }
      
      dropArea.insertBefore(fileDisplay, dropArea.querySelector('p'));
      dropArea.querySelector('p').style.display = 'none';
      
      // Add event listener for remove button
      fileDisplay.querySelector('.remove-file').addEventListener('click', function() {
        fileDisplay.remove();
        fileInput.value = '';
        dropArea.querySelector('p').style.display = 'block';
      });
    }
  
    function formatFileSize(bytes) {
      if (bytes === 0) return '0 Bytes';
      const k = 1024;
      const sizes = ['Bytes', 'KB', 'MB', 'GB'];
      const i = Math.floor(Math.log(bytes) / Math.log(k));
      return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
    }
  
    // Form submission - REAL API CALL
    cvForm.addEventListener('submit', async function(e) {
      e.preventDefault();
      
      if (!fileInput.files.length) {
        alert('Please select a file first.');
        return;
      }

      // Validate file type
      const file = fileInput.files[0];
      if (file.type !== 'application/pdf') {
        alert('Please upload a PDF file only.');
        return;
      }
  
      // Show processing modal
      statusModal.style.display = 'block';
      
      // Update progress steps
      const steps = document.querySelectorAll('.processing-step');
      const progressBar = document.getElementById('progressBar');
      const progressText = document.getElementById('progressText');
      
      // Step 1: Analyzing
      steps.forEach(step => step.classList.remove('active'));
      steps[0].classList.add('active');
      progressBar.style.width = '25%';
      progressText.textContent = 'Analyzing your resume content...';
      
      try {
        // Prepare form data
        const formData = new FormData();
        formData.append('file', file);
        
        const prompt = document.getElementById('prompt').value;
        const jobTitle = document.getElementById('jobTitle').value;
        
        if (prompt) {
          formData.append('prompt', prompt);
        }
        if (jobTitle) {
          formData.append('jobTitle', jobTitle);
        }

        // Step 2: Enhancing
        setTimeout(() => {
          steps.forEach(step => step.classList.remove('active'));
          steps[1].classList.add('active');
          progressBar.style.width = '50%';
          progressText.textContent = 'Enhancing your resume with AI...';
        }, 1000);

        // Step 3: Optimizing
        setTimeout(() => {
          steps.forEach(step => step.classList.remove('active'));
          steps[2].classList.add('active');
          progressBar.style.width = '75%';
          progressText.textContent = 'Optimizing for ATS compatibility...';
        }, 2000);

        // Make the actual API call
        console.log('Sending CV enhancement request...');
        const response = await fetch('/webhook/resume-builder', {
          method: 'POST',
          body: formData
        });

        console.log('Response received:', response.status);

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to enhance resume.');
        }

        // Step 4: Finalizing
        steps.forEach(step => step.classList.remove('active'));
        steps[3].classList.add('active');
        progressBar.style.width = '100%';
        progressText.textContent = 'Finalizing your enhanced resume...';

        // Get the enhanced PDF
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        
        // Set up download link
        downloadLink.href = url;
        downloadLink.download = `Enhanced_${file.name.replace(/\.[^/.]+$/, '')}.pdf`;
        downloadLink.classList.add('ready');
        
        // Show success modal
        setTimeout(() => {
          statusModal.style.display = 'none';
          resultModal.style.display = 'block';
        }, 1000);

        console.log('CV enhancement completed successfully!');

      } catch (err) {
        console.error('CV Enhancement Error:', err);
        
        // Hide processing modal
        statusModal.style.display = 'none';
        
        // Show error message
        alert('Error: ' + err.message + '\n\nPlease try again or contact support if the problem persists.');
      }
    });
  
    // Close modals
    closeModals.forEach(btn => {
      btn.addEventListener('click', function() {
        statusModal.style.display = 'none';
        resultModal.style.display = 'none';
      });
    });
  
    // Close modals when clicking outside
    window.addEventListener('click', function(e) {
      if (e.target === statusModal) {
        statusModal.style.display = 'none';
      }
      if (e.target === resultModal) {
        resultModal.style.display = 'none';
      }
    });
  
    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
          behavior: 'smooth'
        });
      });
    });
  });