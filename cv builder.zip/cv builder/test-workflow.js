const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');

// Test configuration
const TEST_CONFIG = {
  baseUrl: 'http://localhost:3000', // Update this to your server URL
  n8nWebhookUrl: 'https://tayyabshabaz1234.app.n8n.cloud/webhook/cv-enhancer',
  testPdfPath: './test-resume.pdf', // Create a test PDF file
  timeout: 180000 // 3 minutes
};

// Test functions
async function testHealthCheck() {
  console.log('🔍 Testing health check...');
  try {
    const response = await axios.get(`${TEST_CONFIG.baseUrl}/health`, { timeout: 5000 });
    console.log('✅ Health check passed:', response.data);
    return true;
  } catch (error) {
    console.error('❌ Health check failed:', error.message);
    return false;
  }
}

async function testN8nWebhook() {
  console.log('🔍 Testing n8n webhook directly...');
  try {
    // Create a simple test payload
    const formData = new FormData();
    formData.append('test', 'true');
    formData.append('sessionId', `test_${Date.now()}`);
    
    const response = await axios.post(TEST_CONFIG.n8nWebhookUrl, formData, {
      headers: formData.getHeaders(),
      timeout: 10000
    });
    
    console.log('✅ n8n webhook is accessible');
    return true;
  } catch (error) {
    console.error('❌ n8n webhook test failed:', error.message);
    return false;
  }
}

async function testFileUpload() {
  console.log('🔍 Testing file upload...');
  try {
    // Check if test PDF exists
    if (!fs.existsSync(TEST_CONFIG.testPdfPath)) {
      console.log('⚠️  Test PDF not found. Creating a simple test file...');
      // Create a simple test file
      const testContent = 'This is a test CV content for testing purposes.';
      fs.writeFileSync(TEST_CONFIG.testPdfPath.replace('.pdf', '.txt'), testContent);
      console.log('📝 Created test text file. Please convert to PDF manually for full testing.');
      return false;
    }

    const formData = new FormData();
    formData.append('file', fs.createReadStream(TEST_CONFIG.testPdfPath));
    formData.append('jobTitle', 'Software Developer');
    formData.append('industry', 'Technology');

    const response = await axios.post(`${TEST_CONFIG.baseUrl}/webhook/resume-builder`, formData, {
      headers: formData.getHeaders(),
      timeout: TEST_CONFIG.timeout,
      responseType: 'arraybuffer'
    });

    console.log('✅ File upload test passed');
    console.log('📊 Response stats:', {
      status: response.status,
      contentLength: response.data.length,
      contentType: response.headers['content-type']
    });

    // Save the enhanced PDF
    const outputPath = './enhanced-test-resume.pdf';
    fs.writeFileSync(outputPath, response.data);
    console.log(`💾 Enhanced PDF saved to: ${outputPath}`);

    return true;
  } catch (error) {
    console.error('❌ File upload test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data.toString());
    }
    return false;
  }
}

async function testErrorHandling() {
  console.log('🔍 Testing error handling...');
  
  // Test 1: No file uploaded
  try {
    const formData = new FormData();
    const response = await axios.post(`${TEST_CONFIG.baseUrl}/webhook/resume-builder`, formData, {
      headers: formData.getHeaders(),
      timeout: 10000
    });
    console.log('❌ Should have returned error for no file');
  } catch (error) {
    if (error.response && error.response.status === 400) {
      console.log('✅ Error handling for no file works correctly');
    } else {
      console.error('❌ Unexpected error for no file test:', error.message);
    }
  }

  // Test 2: Invalid file type
  try {
    const formData = new FormData();
    formData.append('file', Buffer.from('test content'), {
      filename: 'test.txt',
      contentType: 'text/plain'
    });
    
    const response = await axios.post(`${TEST_CONFIG.baseUrl}/webhook/resume-builder`, formData, {
      headers: formData.getHeaders(),
      timeout: 10000
    });
    console.log('❌ Should have returned error for invalid file type');
  } catch (error) {
    if (error.response && error.response.status === 400) {
      console.log('✅ Error handling for invalid file type works correctly');
    } else {
      console.error('❌ Unexpected error for invalid file type test:', error.message);
    }
  }
}

// Main test runner
async function runTests() {
  console.log('🚀 Starting CV Enhancer Workflow Tests\n');
  
  const tests = [
    { name: 'Health Check', fn: testHealthCheck },
    { name: 'N8N Webhook', fn: testN8nWebhook },
    { name: 'File Upload', fn: testFileUpload },
    { name: 'Error Handling', fn: testErrorHandling }
  ];

  let passed = 0;
  let total = tests.length;

  for (const test of tests) {
    console.log(`\n📋 Running: ${test.name}`);
    console.log('─'.repeat(50));
    
    const result = await test.fn();
    if (result) passed++;
    
    console.log('─'.repeat(50));
  }

  console.log(`\n📊 Test Results: ${passed}/${total} tests passed`);
  
  if (passed === total) {
    console.log('🎉 All tests passed! Your CV enhancer workflow is working correctly.');
  } else {
    console.log('⚠️  Some tests failed. Please check the configuration and try again.');
  }
}

// Run tests if this file is executed directly
if (require.main === module) {
  runTests().catch(console.error);
}

module.exports = {
  testHealthCheck,
  testN8nWebhook,
  testFileUpload,
  testErrorHandling,
  runTests
}; 