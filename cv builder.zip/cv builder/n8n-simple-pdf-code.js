// Simple PDF Generation for N8N - This will work without TypeScript errors

// Get enhanced text from AI agent
const enhancedText = $input.first().json.enhancedText || $input.first().json.text || 'No enhanced text available';
const originalFileName = $input.first().json.originalFileName || 'Resume';

// Create PDF document
const doc = new PDFDocument({
  size: 'A4',
  margins: {
    top: 40,
    bottom: 40,
    left: 40,
    right: 40
  }
});

// Set up basic styling
doc.font('Helvetica');
doc.fontSize(11);

// Add content to PDF
doc.text(enhancedText, {
  align: 'left',
  lineGap: 3
});

// Generate PDF buffer - Simple approach
const chunks = [];
doc.on('data', function(chunk) {
  chunks.push(chunk);
});

doc.on('end', function() {
  // Create buffer from chunks
  let pdfBuffer;
  try {
    pdfBuffer = Buffer.concat(chunks);
  } catch (e) {
    // Fallback if Buffer.concat fails
    pdfBuffer = Buffer.from(chunks.join(''));
  }
  
  // Return result
  return {
    json: {
      pdfContent: pdfBuffer,
      fileName: `Enhanced_${originalFileName.replace(/\.[^/.]+$/, '')}.pdf`,
      originalFileName: originalFileName,
      enhancedText: enhancedText
    }
  };
});

// End the document
doc.end(); 