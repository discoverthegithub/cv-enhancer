// CV Enhancement PDF Generator - Fixed for N8N
// This code is designed to work in n8n's Code node environment

// Get enhanced text from AI agent
const enhancedText = $input.first().json.enhancedText || $input.first().json.text || 'No enhanced text available';
const originalFileName = $input.first().json.originalFileName || 'Resume';

// Create PDF document with professional formatting
const doc = new PDFDocument({
  size: 'A4',
  margins: {
    top: 40,
    bottom: 40,
    left: 40,
    right: 40
  },
  info: {
    Title: 'Enhanced CV',
    Author: 'AI CV Enhancer',
    Subject: 'Professional Resume'
  }
});

// Set up professional fonts and styling
doc.font('Helvetica');

// Function to add section headers
function addSectionHeader(text) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .fillColor('#2c3e50')
     .text(text, { continued: false })
     .moveDown(0.5);
}

// Function to add content
function addContent(text) {
  doc.fontSize(11)
     .font('Helvetica')
     .fillColor('#34495e')
     .text(text, { 
       align: 'left',
       lineGap: 3,
       paragraphGap: 5
     })
     .moveDown(0.5);
}

// Parse and format the enhanced text
const lines = enhancedText.split('\n');
let currentSection = '';
let currentContent = '';

for (let line of lines) {
  line = line.trim();
  
  // Check if this is a section header (all caps, bold indicators, etc.)
  if (line.match(/^[A-Z\s]+$/) || 
      line.match(/^(EDUCATION|EXPERIENCE|SKILLS|PROJECTS|CERTIFICATIONS|LANGUAGES|REFERENCES)/i) ||
      line.match(/^[A-Z][a-z\s]+:$/)) {
    
    // Add previous section if exists
    if (currentSection && currentContent) {
      addSectionHeader(currentSection);
      addContent(currentContent);
      currentContent = '';
    }
    
    currentSection = line;
  } else if (line) {
    // Add to current content
    if (currentContent) currentContent += '\n';
    currentContent += line;
  }
}

// Add the last section
if (currentSection && currentContent) {
  addSectionHeader(currentSection);
  addContent(currentContent);
}

// If no sections were detected, add as plain text
if (!currentSection) {
  addContent(enhancedText);
}

// Generate PDF buffer using n8n's approach
const chunks = [];
doc.on('data', function(chunk) {
  chunks.push(chunk);
});

doc.on('end', function() {
  // Use Buffer.from instead of Buffer.concat for better compatibility
  const pdfBuffer = Buffer.from(Buffer.concat(chunks));
  
  // Return the result in n8n format
  return {
    json: {
      pdfContent: pdfBuffer,
      fileName: `Enhanced_${originalFileName.replace(/\.[^/.]+$/, '')}.pdf`,
      originalFileName: originalFileName,
      enhancedText: enhancedText
    }
  };
});

// Alternative approach if the above doesn't work
// This is a simpler version that should work in all n8n environments
try {
  doc.end();
} catch (error) {
  // Fallback: return the enhanced text as plain text if PDF generation fails
  return {
    json: {
      enhancedText: enhancedText,
      fileName: `Enhanced_${originalFileName.replace(/\.[^/.]+$/, '')}.txt`,
      originalFileName: originalFileName,
      error: 'PDF generation failed, returning text instead'
    }
  };
} 