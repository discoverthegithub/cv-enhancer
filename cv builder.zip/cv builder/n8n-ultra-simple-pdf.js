// Ultra Simple PDF Generation for N8N

// Get the enhanced text
const enhancedText = $input.first().json.enhancedText || $input.first().json.text || 'No enhanced text available';
const originalFileName = $input.first().json.originalFileName || 'Resume';

// Create PDF
const doc = new PDFDocument();

// Add text
doc.text(enhancedText);

// Collect PDF data
const chunks = [];
doc.on('data', function(chunk) {
  chunks.push(chunk);
});

doc.on('end', function() {
  const pdfBuffer = Buffer.concat(chunks);
  
  return {
    json: {
      pdfContent: pdfBuffer,
      fileName: `Enhanced_${originalFileName.replace(/\.[^/.]+$/, '')}.pdf`,
      enhancedText: enhancedText
    }
  };
});

doc.end(); 