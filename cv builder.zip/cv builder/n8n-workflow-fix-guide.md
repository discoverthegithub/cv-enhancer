# N8N Workflow Binary Data Fix Guide

## The Problem
The error "The item has no binary field '[object Object]'" occurs because n8n can't find the binary data in the expected format.

## Step-by-Step Solution

### Step 1: Add Debug Node
Add a **Set** node between Webhook and HTTP Request:

**Set Node Configuration:**
```
Mode: Run Once for All Items
Keep Only Set: OFF
Values to Set:
  - Name: debug_binary
  - Value: {{ $binary }}
  - Name: debug_json
  - Value: {{ $json }}
  - Name: debug_file_name
  - Value: {{ $json.originalFileName }}
```

### Step 2: Fix HTTP Request Node
**Exact Configuration:**
```
Method: POST
URL: https://pdftotext.io/api/upload
Authentication: None
Send Query Parameters: OFF
Send Headers: OFF
Send Body: ON
Body Content Type: Form-Data
Body Parameters:
  - Parameter Type: n8n Binary File
  - Name: file
  - Input Data Field Name: {{ $binary }}
```

### Step 3: Test Each Option
If the above doesn't work, try these alternatives in order:

**Option 1:**
```
Input Data Field Name: {{ $binary }}
```

**Option 2:**
```
Input Data Field Name: {{ $json.file }}
```

**Option 3:**
```
Input Data Field Name: {{ $binary.file }}
```

**Option 4:**
```
Input Data Field Name: {{ $json }}
```

### Step 4: Alternative Approach - Use Code Node
If HTTP Request still fails, use a Code node to prepare the data:

**Code Node Configuration:**
```javascript
// Prepare binary data for HTTP Request
const binaryData = $input.first().binary;
const jsonData = $input.first().json;

// Create a new item with proper binary structure
return {
  json: {
    ...jsonData,
    preparedFile: binaryData
  },
  binary: {
    file: binaryData
  }
};
```

Then in HTTP Request:
```
Input Data Field Name: {{ $binary.file }}
```

### Step 5: Complete Workflow Structure
```
Webhook → Set (Debug) → Code (Prepare Data) → HTTP Request → IF → AI Agent → Code (PDF) → Respond
```

### Step 6: Test the Fix
1. Execute the workflow with a test PDF
2. Check the debug node output
3. Verify the HTTP Request receives proper binary data
4. Monitor the execution logs

## Common Issues and Solutions

### Issue 1: Binary data not found
**Solution:** Use `{{ $binary }}` instead of `{{ $binary.data }}`

### Issue 2: File field not accessible
**Solution:** Use `{{ $json.file }}` or add a Code node to restructure data

### Issue 3: FormData not working
**Solution:** Ensure Content-Type is set to multipart/form-data

### Issue 4: File size issues
**Solution:** Check if file is under 10MB limit

## Debugging Steps

1. **Check Webhook Output:**
   - Execute webhook node only
   - Verify binary data is present
   - Check file metadata

2. **Test HTTP Request Separately:**
   - Use a simple test file
   - Check if pdftotext.io API is accessible
   - Verify API response format

3. **Monitor Execution Logs:**
   - Check n8n execution history
   - Look for specific error messages
   - Verify data flow between nodes

## Expected Data Structure
After webhook receives file:
```json
{
  "json": {
    "originalFileName": "test.pdf",
    "fileSize": "12345",
    "mimeType": "application/pdf"
  },
  "binary": {
    "file": {
      "data": "base64_encoded_data",
      "mimeType": "application/pdf",
      "fileName": "test.pdf"
    }
  }
}
```

## Final Configuration
The working configuration should be:
```
HTTP Request Node:
- Method: POST
- URL: https://pdftotext.io/api/upload
- Body Content Type: Form-Data
- Parameter Type: n8n Binary File
- Name: file
- Input Data Field Name: {{ $binary }}
``` 