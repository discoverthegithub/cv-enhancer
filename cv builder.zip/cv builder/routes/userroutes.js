const express = require('express');
const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const router = express.Router();

// Configure multer for file uploads (in-memory storage)
const storage = multer.memoryStorage();
const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024, // 10MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow only PDF files for CV enhancement
    if (file.mimetype === 'application/pdf') {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF files are allowed for CV enhancement.'), false);
    }
  }
});

// POST route to handle CV upload and enhancement
router.post('/webhook/resume-builder', upload.single('file'), async (req, res) => {
  try {
    // Check if file was uploaded
    if (!req.file) {
      return res.status(400).json({ 
        error: 'No file uploaded',
        message: 'Please upload a PDF file to enhance your CV.'
      });
    }

    console.log('CV Enhancement Request:', {
      filename: req.file.originalname,
      size: req.file.size,
      type: req.file.mimetype,
      timestamp: new Date().toISOString()
    });

    // Prepare data to send to n8n in the correct format
    const formData = new FormData();
    
    // Send the file buffer directly as binary data
    formData.append('file', req.file.buffer, {
      filename: req.file.originalname,
      contentType: req.file.mimetype,
      knownLength: req.file.size
    });
    
    // Add optional parameters if provided
    if (req.body.prompt) {
      formData.append('prompt', req.body.prompt);
    }
    
    if (req.body.jobTitle) {
      formData.append('jobTitle', req.body.jobTitle);
    }

    if (req.body.industry) {
      formData.append('industry', req.body.industry);
    }

    // Add session ID for tracking
    const sessionId = `cv_enhancement_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    formData.append('sessionId', sessionId);

    // Add file metadata for n8n
    formData.append('originalFileName', req.file.originalname);
    formData.append('fileSize', req.file.size.toString());
    formData.append('mimeType', req.file.mimetype);

    // Send to n8n webhook
    const n8nWebhookUrl = 'https://tayyabshabaz1234.app.n8n.cloud/webhook/cv-enhancer';
    
    console.log('Sending to n8n workflow:', n8nWebhookUrl);
    console.log('Session ID:', sessionId);
    console.log('File details:', {
      name: req.file.originalname,
      size: req.file.size,
      type: req.file.mimetype
    });
    
    const n8nResponse = await axios.post(n8nWebhookUrl, formData, {
      headers: {
        ...formData.getHeaders(),
        'Content-Length': formData.getLengthSync()
      },
      responseType: 'arraybuffer', // Expect binary response (PDF)
      timeout: 180000 // 3 minutes timeout for AI processing
    });

    console.log('n8n workflow completed successfully:', {
      status: n8nResponse.status,
      contentLength: n8nResponse.data.length,
      sessionId: sessionId
    });

    // Check if response is a PDF or error JSON
    const contentType = n8nResponse.headers['content-type'];
    
    if (contentType && contentType.includes('application/pdf')) {
      // Success - return enhanced PDF
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="Enhanced_${req.file.originalname.replace(/\.[^/.]+$/, '')}.pdf"`);
      res.setHeader('X-Session-ID', sessionId);
      res.setHeader('X-Processing-Time', Date.now() - Date.parse(req.headers['x-request-time'] || Date.now()));
      
      res.send(n8nResponse.data);
    } else {
      // Error response from n8n
      const errorData = JSON.parse(n8nResponse.data.toString());
      console.error('n8n workflow error:', errorData);
      
      res.status(500).json({
        error: errorData.error || 'CV enhancement failed',
        message: errorData.message || 'An error occurred during CV enhancement',
        sessionId: sessionId
      });
    }

  } catch (error) {
    console.error('CV Enhancement Error:', {
      error: error.message,
      stack: error.stack,
      timestamp: new Date().toISOString()
    });
    
    if (error.response) {
      // n8n returned an error
      console.error('n8n error response:', {
        status: error.response.status,
        headers: error.response.headers
      });
      
      try {
        const errorData = JSON.parse(error.response.data.toString());
        res.status(500).json({ 
          error: errorData.error || 'AI enhancement failed', 
          message: errorData.message || 'The AI service returned an error. Please check the workflow configuration.',
          sessionId: errorData.sessionId
        });
      } catch (parseError) {
        res.status(500).json({ 
          error: 'AI enhancement failed', 
          message: 'The AI service returned an unexpected error format.',
          sessionId: sessionId
        });
      }
    } else if (error.code === 'ECONNREFUSED') {
      // n8n is not running
      res.status(503).json({ 
        error: 'Service unavailable', 
        message: 'The AI enhancement service is not running. Please try again later.',
        sessionId: sessionId
      });
    } else if (error.code === 'ETIMEDOUT') {
      // Request timed out
      res.status(408).json({ 
        error: 'Request timeout', 
        message: 'The CV enhancement process took too long. Please try again with a smaller file.',
        sessionId: sessionId
      });
    } else {
      // Other errors
      res.status(500).json({ 
        error: 'Internal server error', 
        message: 'Something went wrong during CV enhancement. Please try again.',
        sessionId: sessionId
      });
    }
  }
});

// GET route to check if n8n is running (health check)
router.get('/health', async (req, res) => {
  try {
    const n8nWebhookUrl = 'https://tayyabshabaz1234.app.n8n.cloud/webhook/health';
    const response = await axios.get(n8nWebhookUrl, { timeout: 5000 });
    res.json({ 
      status: 'healthy', 
      n8n: 'running',
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(503).json({ 
      status: 'unhealthy', 
      n8n: 'not running',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// GET route to get workflow status
router.get('/status', async (req, res) => {
  try {
    const sessionId = req.query.sessionId;
    if (!sessionId) {
      return res.status(400).json({ error: 'Session ID is required' });
    }

    // You can implement session tracking here
    res.json({ 
      status: 'completed',
      sessionId: sessionId,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ 
      error: 'Failed to get status',
      message: error.message
    });
  }
});

module.exports = router;