const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');

// Test configuration
const TEST_CONFIG = {
  baseUrl: 'http://localhost:3000',
  n8nUrl: 'https://tayyabshabaz1234.app.n8n.cloud/webhook/cv-enhancer',
  testPdfPath: './test-resume.pdf'
};

async function testBackendHealth() {
  console.log('🔍 Testing backend health...');
  try {
    const response = await axios.get(`${TEST_CONFIG.baseUrl}/health`);
    console.log('✅ Backend is healthy:', response.data);
    return true;
  } catch (error) {
    console.error('❌ Backend health check failed:', error.message);
    return false;
  }
}

async function testN8nWebhook() {
  console.log('🔍 Testing n8n webhook directly...');
  try {
    const formData = new FormData();
    formData.append('test', 'true');
    formData.append('sessionId', `test_${Date.now()}`);
    
    const response = await axios.post(TEST_CONFIG.n8nUrl, formData, {
      headers: formData.getHeaders(),
      timeout: 10000
    });
    
    console.log('✅ n8n webhook is accessible');
    return true;
  } catch (error) {
    console.error('❌ n8n webhook test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response data:', error.response.data.toString());
    }
    return false;
  }
}

async function testFullIntegration() {
  console.log('🔍 Testing full integration...');
  
  // Check if test PDF exists
  if (!fs.existsSync(TEST_CONFIG.testPdfPath)) {
    console.log('⚠️  Test PDF not found. Creating a simple test file...');
    const testContent = 'This is a test CV content for testing purposes.';
    fs.writeFileSync(TEST_CONFIG.testPdfPath.replace('.pdf', '.txt'), testContent);
    console.log('📝 Created test text file. Please convert to PDF manually for full testing.');
    return false;
  }

  try {
    const formData = new FormData();
    formData.append('file', fs.createReadStream(TEST_CONFIG.testPdfPath));
    formData.append('jobTitle', 'Software Developer');
    formData.append('prompt', 'Make this resume more professional');

    console.log('📤 Sending request to backend...');
    const response = await axios.post(`${TEST_CONFIG.baseUrl}/webhook/resume-builder`, formData, {
      headers: formData.getHeaders(),
      timeout: 180000, // 3 minutes
      responseType: 'arraybuffer'
    });

    console.log('✅ Full integration test passed!');
    console.log('📊 Response stats:', {
      status: response.status,
      contentLength: response.data.length,
      contentType: response.headers['content-type']
    });

    // Save the enhanced PDF
    const outputPath = './enhanced-test-resume.pdf';
    fs.writeFileSync(outputPath, response.data);
    console.log(`💾 Enhanced PDF saved to: ${outputPath}`);

    return true;
  } catch (error) {
    console.error('❌ Full integration test failed:', error.message);
    if (error.response) {
      console.error('Response status:', error.response.status);
      console.error('Response headers:', error.response.headers);
      try {
        const errorData = JSON.parse(error.response.data.toString());
        console.error('Error details:', errorData);
      } catch (e) {
        console.error('Raw error data:', error.response.data.toString());
      }
    }
    return false;
  }
}

async function runIntegrationTests() {
  console.log('🚀 Starting Integration Tests\n');
  
  const tests = [
    { name: 'Backend Health', fn: testBackendHealth },
    { name: 'N8N Webhook', fn: testN8nWebhook },
    { name: 'Full Integration', fn: testFullIntegration }
  ];

  let passed = 0;
  let total = tests.length;

  for (const test of tests) {
    console.log(`\n📋 Running: ${test.name}`);
    console.log('─'.repeat(50));
    
    const result = await test.fn();
    if (result) passed++;
    
    console.log('─'.repeat(50));
  }

  console.log(`\n📊 Test Results: ${passed}/${total} tests passed`);
  
  if (passed === total) {
    console.log('🎉 All tests passed! Your integration is working correctly.');
    console.log('\n📝 Next steps:');
    console.log('1. Start your Node.js server: npm start');
    console.log('2. Open your website in the browser');
    console.log('3. Upload a PDF file and test the enhancement');
  } else {
    console.log('⚠️  Some tests failed. Please check:');
    console.log('1. Is your Node.js server running?');
    console.log('2. Is your n8n workflow active?');
    console.log('3. Are the URLs correct?');
  }
}

// Run tests if this file is executed directly
if (require.main === module) {
  runIntegrationTests().catch(console.error);
}

module.exports = {
  testBackendHealth,
  testN8nWebhook,
  testFullIntegration,
  runIntegrationTests
}; 