# Complete N8N CV Enhancer Workflow Guide

## Workflow Overview
This workflow will:
1. Receive a PDF CV via webhook
2. Extract text from the PDF
3. Enhance the CV content using AI
4. Generate a new formatted PDF
5. Return the enhanced CV

## Step-by-Step Workflow Setup

### Step 1: Webhook Node (Trigger)
**Node Type:** Webhook
**Configuration:**
- **HTTP Method:** POST
- **Path:** `cv-enhancer`
- **Authentication:** None
- **Respond:** Using 'Respond to Webhook' Node
- **Options:** No properties needed

**Settings:**
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: OFF
- On Error: Stop Workflow

### Step 2: Extract Text from PDF
**Node Type:** HTTP Request
**Configuration:**
- **Method:** POST
- **URL:** `https://pdftotext.io/api/upload`
- **Authentication:** None
- **Send Query Parameters:** OFF
- **Send Headers:** OFF
- **Send Body:** ON
- **Body Content Type:** Form-Data
- **Body Parameters:**
  - Name: `file`
  - Parameter Type: `n8n Binary File`
  - Input Data Field Name: `{{ $binary.data }}`

**Settings:**
- SSL Certificates: OFF
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: ON (3 attempts)
- On Error: Stop Workflow

### Step 3: Validate Text Extraction
**Node Type:** IF
**Configuration:**
- **Condition 1:**
  - Value 1: `{{ $json.text }}`
  - Operation: Exists
  - Value 2: (leave empty)

**Settings:**
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: OFF
- On Error: Stop Workflow

### Step 4: AI Enhancement
**Node Type:** AI Agent
**Configuration:**
- **Source for Prompt:** Define below
- **Prompt (User Message):**
```
You are an expert resume/CV enhancer with deep knowledge of professional writing and ATS (Applicant Tracking System) optimization. 

Please enhance the following resume by:

1. **Professional Language Enhancement:**
   - Improve professional terminology and industry-specific language
   - Replace weak verbs with strong action verbs
   - Ensure consistent tense and professional tone

2. **ATS Optimization:**
   - Add relevant keywords for the industry/role
   - Ensure proper keyword placement and density
   - Optimize for automated screening systems

3. **Content Improvement:**
   - Make bullet points more impactful and achievement-focused
   - Quantify achievements where possible (numbers, percentages, metrics)
   - Improve clarity and conciseness

4. **Structure and Format:**
   - Maintain clear section headers
   - Ensure logical flow and organization
   - Keep consistent formatting

5. **Professional Standards:**
   - Remove any unprofessional content
   - Ensure proper grammar and spelling
   - Maintain professional length (1-2 pages)

Resume text to enhance:
{{ $json.text }}

Please return the enhanced resume in a clean, professional format that maintains the original structure while significantly improving the content quality. Focus on making it more compelling and ATS-friendly.
```

- **Require Specific Output Format:** OFF
- **Enable Fallback Model:** ON

**Chat Model Configuration:**
- **Model:** Google Gemini Chat Model
- **API Key:** [Your Gemini API Key]
- **Model:** gemini-1.5-flash

**Memory Configuration:**
- **Memory Type:** Simple Memory
- **Session ID:** `{{ $json.sessionId || 'cv-enhancement' }}`

**Settings:**
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: ON (2 attempts)
- On Error: Stop Workflow

### Step 5: Validate AI Enhancement
**Node Type:** IF
**Configuration:**
- **Condition 1:**
  - Value 1: `{{ $json.enhancedText }}`
  - Operation: Exists
  - Value 2: (leave empty)

**Settings:**
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: OFF
- On Error: Stop Workflow

### Step 6: Generate Enhanced PDF
**Node Type:** Code
**Configuration:**
- **Mode:** Run Once for All Items
- **Language:** JavaScript

**JavaScript Code:**
```javascript
// CV Enhancement PDF Generator
const PDFDocument = require('pdfkit');

// Get enhanced text from AI agent
const enhancedText = $input.first().json.enhancedText || $input.first().json.text || 'No enhanced text available';
const originalFileName = $input.first().json.originalFileName || 'Resume';

// Create PDF document with professional formatting
const doc = new PDFDocument({
  size: 'A4',
  margins: {
    top: 40,
    bottom: 40,
    left: 40,
    right: 40
  },
  info: {
    Title: 'Enhanced CV',
    Author: 'AI CV Enhancer',
    Subject: 'Professional Resume'
  }
});

// Set up professional fonts and styling
doc.font('Helvetica');

// Function to add section headers
function addSectionHeader(text) {
  doc.fontSize(14)
     .font('Helvetica-Bold')
     .fillColor('#2c3e50')
     .text(text, { continued: false })
     .moveDown(0.5);
}

// Function to add content
function addContent(text) {
  doc.fontSize(11)
     .font('Helvetica')
     .fillColor('#34495e')
     .text(text, { 
       align: 'left',
       lineGap: 3,
       paragraphGap: 5
     })
     .moveDown(0.5);
}

// Parse and format the enhanced text
const lines = enhancedText.split('\n');
let currentSection = '';
let currentContent = '';

for (let line of lines) {
  line = line.trim();
  
  // Check if this is a section header (all caps, bold indicators, etc.)
  if (line.match(/^[A-Z\s]+$/) || 
      line.match(/^(EDUCATION|EXPERIENCE|SKILLS|PROJECTS|CERTIFICATIONS|LANGUAGES|REFERENCES)/i) ||
      line.match(/^[A-Z][a-z\s]+:$/)) {
    
    // Add previous section if exists
    if (currentSection && currentContent) {
      addSectionHeader(currentSection);
      addContent(currentContent);
      currentContent = '';
    }
    
    currentSection = line;
  } else if (line) {
    // Add to current content
    if (currentContent) currentContent += '\n';
    currentContent += line;
  }
}

// Add the last section
if (currentSection && currentContent) {
  addSectionHeader(currentSection);
  addContent(currentContent);
}

// If no sections were detected, add as plain text
if (!currentSection) {
  addContent(enhancedText);
}

// Generate PDF buffer
const chunks = [];
doc.on('data', chunk => chunks.push(chunk));
doc.on('end', () => {
  const pdfBuffer = Buffer.concat(chunks);
  return {
    pdfContent: pdfBuffer,
    fileName: `Enhanced_${originalFileName.replace(/\.[^/.]+$/, '')}.pdf`,
    originalFileName: originalFileName,
    enhancedText: enhancedText
  };
});

doc.end();
```

**Settings:**
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: OFF
- On Error: Stop Workflow

### Step 7: Respond with Enhanced PDF
**Node Type:** Respond to Webhook
**Configuration:**
- **Respond With:** First Incoming Item
- **Response Headers:**
  - **Content-Type:** `application/pdf`
  - **Content-Disposition:** `attachment; filename="{{ $json.fileName }}"`
- **Put Response in Field:** `{{ $json.pdfContent }}`

**Settings:**
- Enable Response Output Branch: OFF
- Always Output Data: OFF
- Execute Once: OFF
- Retry On Fail: OFF
- On Error: Stop Workflow

## Error Handling Nodes

### Error Handler 1: Text Extraction Failed
**Node Type:** Respond to Webhook
**Configuration:**
- **Respond With:** First Incoming Item
- **Response Headers:**
  - **Content-Type:** `application/json`
- **Put Response in Field:**
```json
{
  "error": "Text extraction failed",
  "message": "Could not extract text from the uploaded PDF. Please ensure the file is a valid PDF document.",
  "status": "error"
}
```

### Error Handler 2: AI Enhancement Failed
**Node Type:** Respond to Webhook
**Configuration:**
- **Respond With:** First Incoming Item
- **Response Headers:**
  - **Content-Type:** `application/json`
- **Put Response in Field:**
```json
{
  "error": "AI enhancement failed",
  "message": "Could not enhance the CV content. Please try again or contact support.",
  "status": "error"
}
```

## Workflow Connections

1. **Webhook** → **HTTP Request** (Extract Text)
2. **HTTP Request** → **IF** (Validate Text)
3. **IF (Text Valid)** → **AI Agent** (Enhance)
4. **IF (Text Invalid)** → **Error Handler 1**
5. **AI Agent** → **IF** (Validate Enhancement)
6. **IF (Enhancement Valid)** → **Code** (Generate PDF)
7. **IF (Enhancement Invalid)** → **Error Handler 2**
8. **Code** → **Respond to Webhook** (Success Response)

## Required Environment Variables

Set these in your n8n environment:
- `GEMINI_API_KEY`: Your Google Gemini API key
- `PDFTOTEXT_API_KEY`: (Optional) If pdftotext.io requires API key

## Testing the Workflow

### Test 1: Basic PDF Upload
1. Upload a simple PDF with clear text
2. Verify text extraction works
3. Check AI enhancement quality
4. Confirm PDF generation

### Test 2: Complex PDF
1. Upload a PDF with tables, images, complex formatting
2. Verify text extraction handles complexity
3. Check enhancement maintains structure

### Test 3: Error Scenarios
1. Upload non-PDF file
2. Upload corrupted PDF
3. Test with empty PDF
4. Verify error responses

## Performance Optimization

1. **Timeout Settings:**
   - HTTP Request: 30 seconds
   - AI Agent: 60 seconds
   - Code: 30 seconds

2. **Retry Logic:**
   - HTTP Request: 3 attempts
   - AI Agent: 2 attempts
   - Others: No retry

3. **Memory Management:**
   - Use streaming for large PDFs
   - Clean up temporary data

## Security Considerations

1. **File Validation:**
   - Check file size limits
   - Validate file types
   - Sanitize filenames

2. **API Security:**
   - Use environment variables for API keys
   - Implement rate limiting
   - Add request validation

3. **Data Privacy:**
   - Don't store sensitive data
   - Implement data retention policies
   - Add audit logging

## Monitoring and Logging

Add these nodes for monitoring:
1. **Set** node to add timestamps
2. **Code** node to log processing steps
3. **Webhook** node to send notifications on completion

This complete workflow will provide a robust CV enhancement service with proper error handling, professional PDF generation, and comprehensive testing capabilities. 